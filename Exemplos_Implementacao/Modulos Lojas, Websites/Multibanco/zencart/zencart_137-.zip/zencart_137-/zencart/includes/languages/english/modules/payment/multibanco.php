<?php
/*
  $Id: transferencia.php, 10/16/2004

  O download do m�dulo deposito/transfer�ncia banc�ria
   pode ser efetuado em http://www.phpmania.org

  Copyright (c) 2004 PHPmania.org <phpmania@mail.com>

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2003 osCommerce
   osCommerce 2.2 Milestone 2 BR Por PHPmania.org
*/

  define('MODULE_PAYMENT_TRANSFERENCIA_TEXT_TITLE', 'Dep�sito/Transfer�ncia Banc�ria');
  define('MODULE_PAYMENT_TRANSFERENCIA_TEXT_DESCRIPTION', 'Dep�sito/Transfer�ncia Banc�ria');

?>
